---
title: "Compleanno: una persona che ha fatto la storia"
date: 2026-02-20
author: "Redazione SDAC"
excerpt: "Un profilo rapido con qualche nota tecnica e un consiglio di visione."
cover_image: "/images/uploads/placeholder.jpg"
tags: ["cinema"]
---

Scrivi qui il testo del compleanno.
